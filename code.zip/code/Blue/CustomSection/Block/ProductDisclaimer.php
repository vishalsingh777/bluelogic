<?php
 
namespace Blue\CustomSection\Block;
 
class ProductDisclaimer extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Blue\CustomSection\Helper\Data $helper,
         array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    public function getExtraInfo()
    {
        return $this->helper->getExtraInfo();
    }
}
