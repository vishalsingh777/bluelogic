<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Blue\Logic\Model\Data;

use Blue\Logic\Api\Data\BluelogicInterface;

class Bluelogic extends \Magento\Framework\Api\AbstractExtensibleObject implements BluelogicInterface
{

    /**
     * Get bluelogic_id
     * @return string|null
     */
    public function getBluelogicId()
    {
        return $this->_get(self::BLUELOGIC_ID);
    }

    /**
     * Set bluelogic_id
     * @param string $bluelogicId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setBluelogicId($bluelogicId)
    {
        return $this->setData(self::BLUELOGIC_ID, $bluelogicId);
    }

    /**
     * Get entity_id
     * @return string|null
     */
    public function getEntityId()
    {
        return $this->_get(self::ENTITY_ID);
    }

    /**
     * Set entity_id
     * @param string $entityId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Blue\Logic\Api\Data\BluelogicExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Blue\Logic\Api\Data\BluelogicExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Blue\Logic\Api\Data\BluelogicExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get sku
     * @return string|null
     */
    public function getSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * Set sku
     * @param string $sku
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * Get vendor_name
     * @return string|null
     */
    public function getVendorName()
    {
        return $this->_get(self::VENDOR_NAME);
    }

    /**
     * Set vendor_name
     * @param string $vendorName
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setVendorName($vendorName)
    {
        return $this->setData(self::VENDOR_NAME, $vendorName);
    }

    /**
     * Get vendor_note
     * @return string|null
     */
    public function getVendorNote()
    {
        return $this->_get(self::VENDOR_NOTE);
    }

    /**
     * Set vendor_note
     * @param string $vendorNote
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setVendorNote($vendorNote)
    {
        return $this->setData(self::VENDOR_NOTE, $vendorNote);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get store_id
     * @return string|null
     */
    public function getStoreId()
    {
        return $this->_get(self::STORE_ID);
    }

    /**
     * Set store_id
     * @param string $storeId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }
}

