<?php

namespace Blue\Logic\Model\Options\Source;
 
class Sku implements \Magento\Framework\Option\ArrayInterface
{
    /*
        Product collection variable
    */ 
    protected $_productCollection;

    public function __construct(
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollection
    ) {
        $this->_productCollection= $productCollection;
    }

	public function toOptionArray() 
    {
        $collection = $this->_productCollection->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)->addFieldToSelect(array('sku'));

        $options = [];
       	$options[] = array( 'label' => 'Please select Department', 'value' => '');

        if ($collection->getSize()) {
            foreach ($collection  as $product) {
                $options[] = array( 
                    'label' => $product->getData('sku') ,
                    'value' => $product->getData('sku')
                );
            }
        }
        
        return $options;
    }
}
