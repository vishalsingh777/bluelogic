<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Blue\Logic\Model;

use Blue\Logic\Api\Data\BluelogicInterface;
use Blue\Logic\Api\Data\BluelogicInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class Bluelogic extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'blue_logic_bluelogic';
    protected $dataObjectHelper;

    protected $bluelogicDataFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param BluelogicInterfaceFactory $bluelogicDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Blue\Logic\Model\ResourceModel\Bluelogic $resource
     * @param \Blue\Logic\Model\ResourceModel\Bluelogic\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        BluelogicInterfaceFactory $bluelogicDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Blue\Logic\Model\ResourceModel\Bluelogic $resource,
        \Blue\Logic\Model\ResourceModel\Bluelogic\Collection $resourceCollection,
        array $data = []
    ) {
        $this->bluelogicDataFactory = $bluelogicDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve bluelogic model with bluelogic data
     * @return BluelogicInterface
     */
    public function getDataModel()
    {
        $bluelogicData = $this->getData();
        
        $bluelogicDataObject = $this->bluelogicDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $bluelogicDataObject,
            $bluelogicData,
            BluelogicInterface::class
        );
        
        return $bluelogicDataObject;
    }
}

