<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Blue\Logic\Api\Data;

interface BluelogicSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get bluelogic list.
     * @return \Blue\Logic\Api\Data\BluelogicInterface[]
     */
    public function getItems();

    /**
     * Set entity_id list.
     * @param \Blue\Logic\Api\Data\BluelogicInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

