<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Blue\Logic\Api\Data;

interface BluelogicInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ENTITY_ID = 'entity_id';
    const STORE_ID = 'store_id';
    const VENDOR_NOTE = 'vendor_note';
    const CREATED_AT = 'created_at';
    const BLUELOGIC_ID = 'bluelogic_id';
    const SKU = 'sku';
    const VENDOR_NAME = 'vendor_name';
    const UPDATED_AT = 'updated_at';

    /**
     * Get bluelogic_id
     * @return string|null
     */
    public function getBluelogicId();

    /**
     * Set bluelogic_id
     * @param string $bluelogicId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setBluelogicId($bluelogicId);

    /**
     * Get entity_id
     * @return string|null
     */
    public function getEntityId();

    /**
     * Set entity_id
     * @param string $entityId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setEntityId($entityId);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Blue\Logic\Api\Data\BluelogicExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Blue\Logic\Api\Data\BluelogicExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Blue\Logic\Api\Data\BluelogicExtensionInterface $extensionAttributes
    );

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setSku($sku);

    /**
     * Get vendor_name
     * @return string|null
     */
    public function getVendorName();

    /**
     * Set vendor_name
     * @param string $vendorName
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setVendorName($vendorName);

    /**
     * Get vendor_note
     * @return string|null
     */
    public function getVendorNote();

    /**
     * Set vendor_note
     * @param string $vendorNote
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setVendorNote($vendorNote);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get store_id
     * @return string|null
     */
    public function getStoreId();

    /**
     * Set store_id
     * @param string $storeId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     */
    public function setStoreId($storeId);
}

