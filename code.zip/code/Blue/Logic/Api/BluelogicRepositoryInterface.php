<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Blue\Logic\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface BluelogicRepositoryInterface
{

    /**
     * Save bluelogic
     * @param \Blue\Logic\Api\Data\BluelogicInterface $bluelogic
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Blue\Logic\Api\Data\BluelogicInterface $bluelogic
    );

    /**
     * Retrieve bluelogic
     * @param string $bluelogicId
     * @return \Blue\Logic\Api\Data\BluelogicInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($bluelogicId);

    /**
     * Retrieve bluelogic matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Blue\Logic\Api\Data\BluelogicSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete bluelogic
     * @param \Blue\Logic\Api\Data\BluelogicInterface $bluelogic
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Blue\Logic\Api\Data\BluelogicInterface $bluelogic
    );

    /**
     * Delete bluelogic by ID
     * @param string $bluelogicId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($bluelogicId);
}

